<?php
 $_SESSION['didUserFound'] = false;

?>
<section class="detailinformation" id="detailinformation">
    <div class="detail">
        <span>Our Location In Windsor</span>
        <h2>Store</h2>
        <li>
            <i class="bx bxs-store"></i>
            <p>University of Windsor</p>
        </li>

        <li>
            <i class="bx bx-phone"></i>
            <p>111 111 1111</p>
        </li>

    
        <li>
            <i class="bx bx-envelope"></i>
            <p>Universityofwindsor.ca</p>
        </li>
    </div>
</section>

<div class="members">
    <div>
        <p>
            <span> Darshil Patel </span> <br />
            Phone: 111 111 1111 <br />
            Email: abc@uwindsor.ca
        </p>
    </div>
    <div>
        <p>
            <span> Afsao Bin Masud </span> <br />
            Phone: 111 111 1111 <br />
            Email: abc@uwindsor.ca
        </p>
    </div>
    <div>
        <p>
            <span> Manush Thaker </span> <br />
            Phone: 111 111 1111 <br />
            Email: abc@uwindsor.ca
        </p>
    </div>

    <div>
        <p>
            <span> Nishrut Patel </span> <br />
            Phone: 111 111 1111 <br />
            Email: abc@uwindsor.ca
        </p>
    </div>

    <div>
        <p>
            <span> Ankit Senjalia </span> <br />
            Phone: 111 111 1111 <br />
            Email: abc@uwindsor.ca
        </p>
    </div>
</div>