<section class="mainpage" id="mainpage">
    <div class="mainpage-text">
        <h1>
            <span>Great art </span>picks up <br />
            where <span>nature ends.</span>
        </h1>
        <p>
            Inspiration is for amateurs. The rest of us just show up and get the work done. <br />
            If you wait around for the clouds to part and a bolt of lightning to strike you in <br />
            the brain, you're not going to make an awful lot of work.<br />
            ― Chuck Close

        </p>
        <a href="./shopNow.php" class="button">Explore our collection</a>
    </div>
</section>