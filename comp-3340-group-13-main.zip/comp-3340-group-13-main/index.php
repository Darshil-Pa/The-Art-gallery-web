<?php
// ob_start();

include("./header.php");

?>

<?php

include("./template/_brief_starting.php");

include("./template/_shop_now.php");

// include("./template/_best_selling.php");

include("./template/_more_about_us.php");


?>

<?php

include("./footer.php");

?>