<?php
// ob_start();

include("./header.php");

?>

<?php

include('./template/_cart.php');

// include("./template/_best_selling.php");


?>

<?php

include("./footer.php");

?>