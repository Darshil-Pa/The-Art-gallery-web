
# THE-NFT Art Gallery

This project is designed to showcase a working art gallery. Users are given the option to an create account and buy digital artwork.
In the website, there are six sections, Home, Collection, About Us, Shopping cart and Login.
On Home page, it shows a good image and quote.
On Collection page, one can see all the collections of art that we have.
User can add products to Shopping cart and save for latter from collection page.
On About Us, it shows some information about website.
from Contact Page, user can find some ways to contact developers.
On cart Page, user can see all the items that are present in the cart. One can delete product from here and can save for latter.
on the bottom of cart page, it shows checkout sections.
Lastly, there is Login Page, where user can login and sign up.




## Live link of website
https://patel991.myweb.cs.uwindsor.ca/group-13/index.php
## Authors

- [@NishrutPatel](https://github.com/nishrut)
- [@DarshilPatel](https://github.com/Darshil-Pa)
- [@AnkitSenjaliya](https://github.com/Ankit-Senjaliya)
- [@ManushThaker](https://github.com/ManushThaker)
- [@AfsaoMasud](https://github.com/notAContrarian)

## Features

- Live previews
- Fullscreen mode
- User login
- shopping cart
- save product for later
- checkout



## Documentation

[Documentation](https://www.canva.com/design/DAE9HfSRVdo/e9udveAIKGqZ8VYfKTOysQ/view?utm_content=DAE9HfSRVdo&utm_campaign=designshare&utm_medium=link&utm_source=publishsharelink)


## Tech Stack

**Framework:** Bootstrap

**Programming Languages:** HTML, CSS, PHP

**Libraries:** Boxicons

