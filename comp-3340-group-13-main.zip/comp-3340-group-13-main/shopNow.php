<?php


include("./header.php");

?>
<br>
<br>
<br>
<?php

include('./template/_shop_now.php');

?>

<?php

include("./footer.php");

?>