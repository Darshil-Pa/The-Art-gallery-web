<?php


include("./header.php");

?>
<br>
<br>
<br>
<?php


include("./template/_collection_animals.php");


?>

<?php

include("./footer.php");

?>